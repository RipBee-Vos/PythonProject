a small, hopefully compatible with most sourceports D64 graphics pack inspired by DBP64 - The Vast Silence.
includes full and lite versions, full changes textures, music, as well as the wolfss, bossbrain, keen doll and MBFDog.
lite lacks these features, as it's intended to be loaded with mapsets that have way more custom resources or clashing artstyles.
both full and lite include support for the ancient sourceport Skulltag, specifically for it's monsters, weapons, most powerups and props.
this also comes with two addons: 
EvilMarine4SS, which replaces the WolfSS sprites with Footman's old zombie marine, and his sounds with Quake 1's enforcer.
MeatballCacos, which replaces the D64 Cacodemon design with a 64-styled version of the classic Doom Caco (armless, spiked) using Thief666's HD sprites as a base.

!! does NOT come with custom maps, this is a graphics/sounds ONLY wad !!

I've tested this with Nugget Doom, Woof! and Zandronum, I've been told it works with Crispy too, hope it works with as many ports as possible.
Feel free to use this as a resource in your own projects as long as full credit is given to me AND the contributors listed below:

known minor issues:
- offsets are a bit bad, but it's so minor idrc enough to fix that.

GENERAL CREDITS:
- Midway: D64 assets
- HorrorMovieRei: original D64 skinpack used as a base, made the 'live stick' sprite
- DrDoctor: misc. custom assets used for textures and props
- Craneo (Me): many custom graphical assets, compiling, frankenspriting the Mastermind, Chaingunner, WolfSS and player crouching + a lot of props

GRAPHICAL CREDITS:
- BigStronk: DeathMachine D64 fonts, D4T blood edit, polishing shotgun, supershotgun and plasmarifle sprites a bit
- DBThanatos: D4T blood
- NMN: Radsuit sprites
- WildWeasel: I used his abandoned/incomplete Doom 64 patch as a base for Patch64
- Cage: some textures, stained glass motherdemon sprites
- DrPySpy: Revenant and ArchVile sprites
- Stefano: porting DOOM ETERNAL D2Guy (used for mugshot), D64Guy, Daisy (used for menu) models to Gmod
- Freedoom: some similar-yet-different textures used to replace base Doom ones
- Ittrav: Icon of Sin texture base
- Scalliano, Gez, fenderc01: PSX Doom fireskies
- Ceeb: Quake 1 textures rip
- Formgen: Wolfenstein Lost Episodes textures
- Nash Muhandes: Dog sprites
- OSJCLatchford: new TNT/AV DOBWIRE texture base
- BLASPHEMER: new flag/banner base
- DrDoctor: new SP_FACE texture, bald shotgunguy base
- Immorpher: Morph64 Bald Shotgunguy edit
- AtomicFrog, Immorpher, Nevander, Molecicco: skybox texture pieces
- BLASPHEMER: new flag/banner base
- ItsNatureToDie: stained glass base
- Zrrion the Insect: stained glass demon key texture
- Mark Quinn: fists Marine used on the D64 marine stained glass
- Amuscaria: hanging tyrant, used for the hanged cyberdemon in AV
- DooMAD: StalungCraeft Knight Sentinel mural texture

SOUND CREDITS:
- GEC Team: Icon of Sin sounds
- ZioMcCall: BDv22 Brutal Wolf SS sounds
- Snaxolotl: Absicion OST
- Jay Reinchard: Title, Intermission and D_E1M1 themes
- Marty Kirra, DrPyspy: ArchVile sounds
- Secret found sound from Quake 1

FRANKENSPRITE SPECIFICS:
Commando Credits: Midway, DrDoctor, Immorpher, Footman, Atomic Frog, Vader, Xim, Korp
Mastermind Credits: Midway, 3DRealms, Immorpher, Sgt_Mark_IV, DrPyspy
WolfSS Credits: Id Software, Midway, UnTrustable, Captain J, Revenant100, DoomJedi, ItsNatureToDie, PSTrooper, Immorpher, ringman, clubey
Crouching player credits: Id Software, Midway, TommyGalano5/TG5

SKULLTAG-SPECIFIC CREDITS:
- DrDoctor: blind pinky, nubaron, imp with mouth, many prop bits, railgun, timesphere
- DrPyspy: skull on haste sphere, archvile statue sprites
- AtomicFrog: Invisibilitysphere sprites
BFG10k credits: Midway, TypicalSF, Amuscaria, JuninhoRPG, Craneo
GrenadeLauncher credits: Midway, Amuscaria, OSJCLatchford, Yukiherz, Craneo
Minigun credits: Craneo, Midway

ADDON CREDITS:
Cage weapon reloads addon credits: Cage
Evil Marine for SS addon credits: Footman/SteelPH, Id Software
Classic Caco Addon credits: Thief666, Charles Heathman, Midway, Craneo, Immorpher, DrDoctor
DoomGirl addon credits: Netherealm Studios/Midway

CREDITS MAY BE INCOMPLETE OR INNACURATE, PLEASE NOTIFY ME FOR ANY MISSING NAMES.